if __name__ == '__main__':
    from .MainGame import main
    main()
